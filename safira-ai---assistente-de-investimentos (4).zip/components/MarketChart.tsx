
import React, { useMemo, useState, useEffect } from 'react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { TimePeriod } from '../types';

interface MarketChartProps {
  symbol: string;
  period: TimePeriod;
  onPeriodChange: (period: TimePeriod) => void;
}

export const MarketChart: React.FC<MarketChartProps> = ({ symbol, period, onPeriodChange }) => {
  const [tick, setTick] = useState(0);

  // Simulação de tempo real a cada 5 segundos
  useEffect(() => {
    const interval = setInterval(() => setTick(t => t + 1), 5000);
    return () => clearInterval(interval);
  }, []);

  const chartData = useMemo(() => {
    let points = 24;
    switch(period) {
      case '5D': points = 5; break;
      case '1M': points = 30; break;
      case '6M': points = 26; break;
      case '1Y': points = 52; break;
    }

    const volatility = period === '1D' ? 0.005 : period === '1Y' ? 0.3 : 0.08;
    
    // Gerar dados em termos de porcentagem relativa a um ponto inicial
    let currentChange = 0;
    return Array.from({ length: points }).map((_, i) => {
      // Simula um "random walk" para a porcentagem
      currentChange += (Math.random() * volatility - (volatility / 2));
      // No último ponto (tempo real), adicionamos um noise extra baseado no tick
      if (i === points - 1) currentChange += (Math.random() * 0.001 - 0.0005);
      
      return {
        time: period === '1D' ? `${i}:00` : period === '1Y' ? `Sem ${i+1}` : `Dia ${i + 1}`,
        percent: parseFloat(currentChange.toFixed(2)),
      };
    });
  }, [symbol, period, tick]);

  const latestChange = chartData[chartData.length - 1].percent;
  const isPositive = latestChange >= 0;

  const periods: TimePeriod[] = ['1D', '5D', '1M', '6M', '1Y'];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className={`w-14 h-14 rounded-2xl bg-slate-900 border flex items-center justify-center font-black text-xl shadow-2xl transition-colors duration-500 ${isPositive ? 'border-emerald-500/30 text-emerald-400' : 'border-red-500/30 text-red-400'}`}>
            {symbol.substring(0, 2).toUpperCase()}
          </div>
          <div>
            <h3 className="text-3xl font-black text-white tracking-tighter uppercase leading-none">{symbol}</h3>
            <div className="flex items-center gap-2 mt-1">
              <span className={`text-xl font-mono font-black ${isPositive ? 'text-emerald-400' : 'text-red-400'}`}>
                {isPositive ? '+' : ''}{latestChange.toFixed(2)}%
              </span>
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest bg-slate-800 px-2 py-0.5 rounded">Tempo Real</span>
            </div>
          </div>
        </div>
        <div className="flex bg-slate-950 p-1.5 rounded-2xl border border-slate-800 shadow-2xl">
          {periods.map((p) => (
            <button
              key={p}
              onClick={() => onPeriodChange(p)}
              className={`px-5 py-2 text-[10px] font-black rounded-xl transition-all duration-300 ${
                period === p 
                  ? 'bg-white text-black shadow-lg shadow-white/10' 
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      <div className="h-80 w-full bg-slate-950/20 rounded-[2rem] p-4 border border-slate-800/50 relative overflow-hidden">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="colorPercent" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={isPositive ? '#10b981' : '#ef4444'} stopOpacity={0.3}/>
                <stop offset="95%" stopColor={isPositive ? '#10b981' : '#ef4444'} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="2 2" vertical={false} stroke="#1e293b" opacity={0.3} />
            <XAxis 
              dataKey="time" 
              stroke="#475569" 
              fontSize={10} 
              fontWeight="900"
              tickLine={false} 
              axisLine={false}
              minTickGap={25}
            />
            <YAxis 
              stroke="#475569" 
              fontSize={10} 
              fontWeight="900"
              tickLine={false} 
              axisLine={false}
              orientation="right"
              tickFormatter={(val) => `${val > 0 ? '+' : ''}${val}%`}
            />
            <Tooltip 
              contentStyle={{ backgroundColor: '#020617', border: '1px solid #1e293b', borderRadius: '16px', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.5)' }}
              itemStyle={{ color: isPositive ? '#10b981' : '#ef4444', fontWeight: '900', fontSize: '14px' }}
              labelStyle={{ color: '#64748b', fontSize: '10px', fontWeight: 'bold', textTransform: 'uppercase' }}
              formatter={(val: number) => [`${val > 0 ? '+' : ''}${val}%`, 'VARIAÇÃO']}
            />
            <Area 
              type="monotone" 
              dataKey="percent" 
              stroke={isPositive ? '#10b981' : '#ef4444'} 
              fillOpacity={1} 
              fill="url(#colorPercent)" 
              strokeWidth={3}
              animationDuration={1000}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
