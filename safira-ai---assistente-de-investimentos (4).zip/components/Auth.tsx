
import React, { useState } from 'react';

interface AuthProps {
  onLogin: (name: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const Auth: React.FC<AuthProps> = ({ onLogin, isOpen, onClose }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [name, setName] = useState('');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-[2.5rem] p-8 shadow-2xl">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-black italic uppercase tracking-tighter">
            {isLogin ? 'Entrar na Safira' : 'Criar Conta'}
          </h2>
          <button onClick={onClose} className="text-slate-500 hover:text-white">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
          </button>
        </div>

        <div className="space-y-4">
          {!isLogin && (
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2">Nome Completo</label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
                placeholder="Seu nome"
              />
            </div>
          )}
          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2">Email</label>
            <input type="email" className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600" placeholder="investidor@exemplo.com" />
          </div>
          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2">Senha</label>
            <input type="password" className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600" placeholder="••••••••" />
          </div>

          <button 
            onClick={() => onLogin(name || 'Investidor')}
            className="w-full bg-blue-600 hover:bg-blue-500 text-white font-black py-4 rounded-2xl transition-all shadow-xl shadow-blue-600/20 active:scale-95 uppercase tracking-widest mt-4"
          >
            {isLogin ? 'Acessar Terminal' : 'Registrar'}
          </button>

          <p className="text-center text-xs text-slate-500 mt-6">
            {isLogin ? 'Não tem conta?' : 'Já tem conta?'}
            <button onClick={() => setIsLogin(!isLogin)} className="text-blue-400 font-bold ml-1 hover:underline">
              {isLogin ? 'Criar agora' : 'Fazer login'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};
