
import React, { useEffect, useState } from 'react';

interface IndexData {
  symbol: string;
  name: string;
  value: string;
  change: number;
  region: string;
}

interface MarketSummaryProps {
  onSelect: (symbol: string) => void;
  selectedSymbol: string;
}

export const MarketSummary: React.FC<MarketSummaryProps> = ({ onSelect, selectedSymbol }) => {
  const [indices, setIndices] = useState<IndexData[]>([
    { symbol: 'IBOV', name: 'Ibovespa', value: '128.450', change: 0.45, region: 'BR' },
    { symbol: 'S&P 500', name: 'S&P 500', value: '5.120', change: -0.12, region: 'US' },
    { symbol: 'NASDAQ', name: 'Nasdaq 100', value: '18.350', change: 1.25, region: 'US' },
    { symbol: 'NIKKEI 225', name: 'Nikkei', value: '38.210', change: 0.92, region: 'JP' },
    { symbol: 'DAX', name: 'Alemanha', value: '18.175', change: 0.82, region: 'EU' },
    { symbol: 'SSE', name: 'Xangai', value: '3.050', change: -0.42, region: 'CN' },
    { symbol: 'FTSE 100', name: 'Londres', value: '8.420', change: 0.15, region: 'UK' },
    { symbol: 'CAC 40', name: 'Paris', value: '7.910', change: 0.33, region: 'FR' },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setIndices(current => current.map(idx => ({
        ...idx,
        change: idx.change + (Math.random() * 0.05 - 0.025)
      })));
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex overflow-x-auto gap-4 pb-4 mb-8 custom-scrollbar no-scrollbar">
      {indices.map((idx) => (
        <button 
          key={idx.symbol} 
          onClick={() => onSelect(idx.symbol)}
          className={`flex-none w-44 text-left bg-slate-900/60 border p-4 rounded-2xl transition-all duration-300 ${
            selectedSymbol === idx.symbol 
              ? 'border-blue-500 ring-2 ring-blue-500/20 bg-blue-500/10 shadow-lg' 
              : 'border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex justify-between items-center mb-1">
            <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">{idx.region}</span>
            <span className={`text-[10px] font-bold ${idx.change >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {idx.change >= 0 ? '+' : ''}{idx.change.toFixed(2)}%
            </span>
          </div>
          <h4 className="text-xs font-black text-slate-200 truncate">{idx.symbol}</h4>
          <p className="text-base font-mono font-bold text-blue-100">{idx.value}</p>
        </button>
      ))}
    </div>
  );
};
