
import React, { useState, useMemo } from 'react';
import { RankingItem, RankingCategory, TimePeriod } from '../types';

interface MarketRankingProps {
  onSelect: (symbol: string) => void;
}

export const MarketRanking: React.FC<MarketRankingProps> = ({ onSelect }) => {
  const [category, setCategory] = useState<RankingCategory>('bolsas');
  const [period, setPeriod] = useState<TimePeriod>('1D');
  const [searchTerm, setSearchTerm] = useState('');

  // Mapeamento semântico aprimorado
  const mapping: Record<string, string> = {
    'japao': 'NIKKEI 225',
    'brasil': 'IBOV',
    'eua': 'S&P 500',
    'eua tech': 'NASDAQ',
    'alemanha': 'DAX',
    'china': 'SSE',
    'franca': 'CAC 40',
    'frança': 'CAC 40',
    'londres': 'FTSE 100',
    'reino unido': 'FTSE 100',
    'japão': 'NIKKEI 225',
    'tecnologia': 'NASDAQ',
    'apple': 'AAPL',
    'nvidia': 'NVDA',
    'tesla': 'TSLA',
    'petrobras': 'PETR4',
    'vale': 'VALE3',
    'asml': 'ASML'
  };

  const fullData: Record<RankingCategory, RankingItem[]> = useMemo(() => ({
    bolsas: [
      { name: 'Nikkei 225', symbol: 'NIKKEI 225', change: 2.15, region: 'JP', type: 'index' },
      { name: 'Nasdaq 100', symbol: 'NASDAQ', change: 1.82, region: 'US', type: 'index' },
      { name: 'DAX 40', symbol: 'DAX', change: 1.44, region: 'EU', type: 'index' },
      { name: 'Ibovespa', symbol: 'IBOV', change: 1.12, region: 'BR', type: 'index' },
      { name: 'S&P 500', symbol: 'S&P 500', change: 0.85, region: 'US', type: 'index' },
      { name: 'FTSE 100', symbol: 'FTSE 100', change: 0.45, region: 'UK', type: 'index' },
      { name: 'Xangai SSE', symbol: 'SSE', change: -0.12, region: 'CN', type: 'index' },
      { name: 'CAC 40', symbol: 'CAC 40', change: 0.33, region: 'FR', type: 'index' },
    ],
    acoes: [
      { name: 'NVIDIA Corp', symbol: 'NVDA', change: 4.25, region: 'US', type: 'stock' },
      { name: 'Tesla Inc', symbol: 'TSLA', change: 3.82, region: 'US', type: 'stock' },
      { name: 'Petrobras PN', symbol: 'PETR4', change: 2.15, region: 'BR', type: 'stock' },
      { name: 'ASML Holding', symbol: 'ASML', change: 1.95, region: 'EU', type: 'stock' },
      { name: 'Apple Inc', symbol: 'AAPL', change: 1.42, region: 'US', type: 'stock' },
      { name: 'Vale ON', symbol: 'VALE3', change: 0.45, region: 'BR', type: 'stock' },
      { name: 'Amazon.com', symbol: 'AMZN', change: 1.15, region: 'US', type: 'stock' },
      { name: 'Itaú Unibanco', symbol: 'ITUB4', change: 0.88, region: 'BR', type: 'stock' },
    ]
  }), []);

  const filteredRankings = useMemo(() => {
    let list = fullData[category];
    const search = searchTerm.toLowerCase().trim();
    
    if (search) {
      const mappedSymbol = mapping[search];
      list = list.filter(item => 
        item.name.toLowerCase().includes(search) || 
        item.symbol.toLowerCase().includes(search) ||
        (mappedSymbol && item.symbol.toUpperCase() === mappedSymbol.toUpperCase())
      );
    }

    const multiplier = period === '1D' ? 1 : period === '5D' ? 3.2 : period === '1M' ? 9 : period === '6M' ? 24 : 42;
    
    return list.map(item => ({
      ...item,
      change: item.change * (multiplier * (0.9 + Math.random() * 0.2))
    })).sort((a, b) => b.change - a.change);
  }, [category, period, searchTerm, fullData]);

  return (
    <div className="bg-slate-900/40 border border-slate-800 rounded-[3rem] p-8 shadow-2xl backdrop-blur-xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
        <div>
          <div className="flex gap-6 mb-2">
            <button 
              onClick={() => setCategory('bolsas')}
              className={`text-sm font-black uppercase tracking-[0.2em] transition-all duration-300 pb-1 border-b-2 ${category === 'bolsas' ? 'text-blue-400 border-blue-400' : 'text-slate-600 border-transparent hover:text-slate-400'}`}
            >
              Exchanges
            </button>
            <button 
              onClick={() => setCategory('acoes')}
              className={`text-sm font-black uppercase tracking-[0.2em] transition-all duration-300 pb-1 border-b-2 ${category === 'acoes' ? 'text-blue-400 border-blue-400' : 'text-slate-600 border-transparent hover:text-slate-400'}`}
            >
              Assets
            </button>
          </div>
          <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.3em] italic">Alpha Ranking Sincronizado</p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 md:flex-none">
            <input 
              type="text"
              placeholder="PESQUISAR: JAPÃO, TECH..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-[10px] font-black rounded-2xl pl-10 pr-4 py-3 w-full md:w-64 focus:outline-none focus:ring-2 focus:ring-blue-600 text-slate-200 uppercase tracking-widest transition-all"
            />
            <svg className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
          </div>
          <select 
            value={period}
            onChange={(e) => setPeriod(e.target.value as any)}
            className="bg-slate-800 border border-slate-700 text-[10px] font-black rounded-2xl px-5 py-3 focus:outline-none text-slate-200 uppercase tracking-widest shadow-xl"
          >
            <option value="1D">Diário</option>
            <option value="5D">5 Dias</option>
            <option value="1M">Mensal</option>
            <option value="6M">Semestral</option>
            <option value="1Y">Anual</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredRankings.length > 0 ? filteredRankings.map((item, idx) => (
          <button 
            key={item.symbol} 
            onClick={() => onSelect(item.symbol)}
            className="flex items-center gap-4 group text-left animate-in fade-in slide-in-from-bottom-2 duration-500"
          >
            <span className="text-sm font-black text-slate-800 italic w-6 shrink-0">#{idx + 1}</span>
            <div className="flex-1 bg-slate-950/40 p-5 rounded-[2rem] border border-slate-800/50 group-hover:border-blue-500/50 group-hover:bg-slate-900/60 transition-all duration-500 flex items-center justify-between">
              <div>
                <p className="text-[13px] font-black text-slate-100 group-hover:text-blue-300 transition-colors uppercase tracking-tight">{item.name}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">{item.region}</span>
                  <span className="w-1 h-1 rounded-full bg-slate-800"></span>
                  <span className="text-[9px] font-black text-blue-500/80 uppercase tracking-widest">{item.symbol}</span>
                </div>
              </div>
              <div className="text-right">
                <span className={`text-sm font-mono font-black ${item.change >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {item.change >= 0 ? '+' : ''}{item.change.toFixed(2)}%
                </span>
                <div className={`h-1 w-14 rounded-full mt-2 ml-auto overflow-hidden bg-slate-800`}>
                   <div 
                    className={`h-full ${item.change >= 0 ? 'bg-emerald-500' : 'bg-red-500'} transition-all duration-1000`} 
                    style={{ width: `${Math.min(Math.abs(item.change) * 2, 100)}%` }}
                   ></div>
                </div>
              </div>
            </div>
          </button>
        )) : (
          <div className="col-span-2 py-20 text-center text-slate-600 font-black uppercase text-xs tracking-[0.5em] border-2 border-dashed border-slate-800 rounded-[2rem]">
            Vácuo de Dados para "{searchTerm}"
          </div>
        )}
      </div>
    </div>
  );
};
