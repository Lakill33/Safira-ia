
export interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  groundingSources?: {
    title: string;
    uri: string;
  }[];
}

export interface RankingItem {
  name: string;
  symbol: string;
  change: number;
  region: string;
  type: 'index' | 'stock';
}

export type TimePeriod = '1D' | '5D' | '1M' | '6M' | '1Y';
export type RankingCategory = 'bolsas' | 'acoes';

export interface User {
  name: string;
  email: string;
  isLoggedIn: boolean;
}
