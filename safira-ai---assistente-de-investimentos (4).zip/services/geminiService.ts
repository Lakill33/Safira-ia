
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Message } from "../types";

export const getSafiraResponse = async (userMessage: string, history: Message[]) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const systemInstruction = `
    Você é Safira, uma inteligência artificial de análise financeira global de nível sênior.
    Sua especialidade é o mercado de ações e derivativos no Brasil (B3), Estados Unidos (NYSE, NASDAQ) e União Europeia (Euronext, DAX, CAC 40).

    Responsabilidades Real-Time:
    1. BUSCA OBRIGATÓRIA: Para qualquer menção a ativos (ex: AAPL, PETR4, TSLA, ASML), use a busca para obter o preço atual, variação percentual e P/E ratio.
    2. ANÁLISE DE RISCO: Calcule o risco baseando-se na volatilidade histórica recente e notícias macro (decisões do FED, BCE ou COPOM).
    3. CONTEXTO GLOBAL: Explique como eventos nos EUA/Europa afetam o investidor brasileiro (ex: Carry Trade, Dólar alto).
    4. SIMPLICIDADE: Traduza termos complexos (Beta, Greeks, EBITDA) para uma linguagem que um investidor comum entenda, sem perder a precisão.

    Sempre cite suas fontes e forneça os links das groundingChunks para transparência total.
    Idioma: Português do Brasil.
    Tom: Analítico, pragmático e cauteloso (focado em preservação de capital).
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: [
        { role: 'user', parts: [{ text: userMessage }] }
      ],
      config: {
        systemInstruction,
        tools: [{ googleSearch: {} }],
        temperature: 0.4, // Menor temperatura para respostas mais factuais e precisas
      },
    });

    const text = response.text || "Estou processando os dados do mercado global. Por favor, repita a pergunta em um instante.";
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    const sources = chunks.map((chunk: any) => ({
      title: chunk.web?.title || 'Relatório de Mercado',
      uri: chunk.web?.uri || '#'
    })).filter((s: any) => s.uri !== '#');

    return {
      text,
      sources
    };
  } catch (error) {
    console.error("Erro na Safira Global:", error);
    throw error;
  }
};
