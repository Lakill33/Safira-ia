
import React, { useState, useEffect } from 'react';
import { ChatBox } from './components/ChatBox';
import { MarketChart } from './components/MarketChart';
import { MarketSummary } from './components/MarketSummary';
import { MarketRanking } from './components/MarketRanking';
import { Auth } from './components/Auth';
import { TimePeriod, User } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'chat' | 'dashboard'>('chat');
  const [selectedSymbol, setSelectedSymbol] = useState<string>('IBOV');
  const [selectedPeriod, setSelectedPeriod] = useState<TimePeriod>('1D');
  const [user, setUser] = useState<User>({ name: '', email: '', isLoggedIn: false });
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  const handleSymbolSelect = (symbol: string) => {
    setSelectedSymbol(symbol.toUpperCase());
    setActiveTab('dashboard');
    if (window.innerWidth < 1024) {
      document.querySelector('main')?.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleLogin = (name: string) => {
    setUser({ name, email: '', isLoggedIn: true });
    setIsAuthOpen(false);
  };

  const handleLogout = () => {
    setUser({ name: '', email: '', isLoggedIn: false });
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#020617] text-slate-100 overflow-hidden font-sans">
      <Auth isOpen={isAuthOpen} onLogin={handleLogin} onClose={() => setIsAuthOpen(false)} />

      {/* Sidebar Desktop */}
      <aside className="hidden lg:flex flex-col w-72 bg-slate-900 border-r border-slate-800/50 p-6 shrink-0 shadow-2xl z-20">
        <div className="flex items-center gap-3 mb-10 p-2 cursor-pointer" onClick={() => setActiveTab('chat')}>
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-700 to-indigo-500 flex items-center justify-center shadow-2xl shadow-blue-500/40 transform rotate-3">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
            </svg>
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tighter italic">SAFIRA <span className="text-blue-500">PRO</span></h1>
            <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.2em]">Alpha Terminal</p>
          </div>
        </div>

        <nav className="flex-1 space-y-1.5">
          <button 
            onClick={() => setActiveTab('chat')}
            className={`w-full flex items-center gap-3 px-5 py-4 rounded-2xl transition-all duration-300 font-bold text-sm ${activeTab === 'chat' ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20 shadow-inner' : 'hover:bg-slate-800/50 text-slate-500'}`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path></svg>
            Chat de Análise
          </button>
          <button 
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center gap-3 px-5 py-4 rounded-2xl transition-all duration-300 font-bold text-sm ${activeTab === 'dashboard' ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20 shadow-inner' : 'hover:bg-slate-800/50 text-slate-500'}`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
            Visão Global
          </button>
        </nav>

        <div className="mt-auto">
          {user.isLoggedIn ? (
            <div className="bg-slate-950/50 p-6 rounded-3xl border border-slate-800/50 shadow-2xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center font-black text-xs">{user.name[0]}</div>
                <div className="overflow-hidden">
                  <p className="text-xs font-black truncate text-white uppercase tracking-tight">{user.name}</p>
                  <p className="text-[9px] font-black text-emerald-400 uppercase tracking-widest">Ativo Premium</p>
                </div>
              </div>
              <button 
                onClick={handleLogout}
                className="w-full py-2.5 bg-slate-800 hover:bg-red-500/10 hover:text-red-400 text-slate-500 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all border border-transparent hover:border-red-500/20"
              >
                Encerrar Sessão
              </button>
            </div>
          ) : (
            <button 
              onClick={() => setIsAuthOpen(true)}
              className="w-full py-5 bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-black uppercase tracking-widest rounded-3xl transition-all shadow-2xl shadow-blue-600/20"
            >
              Criar Conta / Login
            </button>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-8 lg:p-10 overflow-y-auto custom-scrollbar bg-gradient-to-br from-[#020617] via-[#0f172a] to-[#020617]">
        <header className="mb-10 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
             <div className="lg:hidden w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-700 to-indigo-500 flex items-center justify-center shadow-xl rotate-3" onClick={() => setIsAuthOpen(true)}>
                <span className="font-black text-white text-2xl italic">S</span>
             </div>
             <div>
              <h2 className="text-3xl font-black text-white tracking-tighter italic uppercase">
                {activeTab === 'chat' ? 'Terminal Safira' : 'Intelligence Dashboard'}
              </h2>
              <p className="flex items-center gap-2 text-slate-500 text-[10px] font-black uppercase tracking-widest mt-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]"></span>
                Sincronia Total: B3 • NYSE • GLOBAL
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-4 bg-slate-900/40 p-4 rounded-[2rem] border border-slate-800 backdrop-blur-md">
            <div className="w-12 h-12 rounded-2xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
               <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path></svg>
            </div>
            <div>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-0.5">Visibilidade</p>
              <p className="text-sm font-black text-white uppercase tracking-tighter italic">Total Global 100%</p>
            </div>
          </div>
        </header>

        <MarketSummary onSelect={handleSymbolSelect} selectedSymbol={selectedSymbol} />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2 space-y-10">
            {activeTab === 'chat' ? (
              <ChatBox />
            ) : (
              <div className="space-y-10">
                <div className="bg-slate-900/20 border border-slate-800/40 p-10 rounded-[3rem] shadow-2xl relative overflow-hidden backdrop-blur-sm">
                  <div className="absolute top-0 right-0 w-80 h-80 bg-blue-600/5 rounded-full blur-[120px] -mr-40 -mt-40"></div>
                  <MarketChart 
                    symbol={selectedSymbol} 
                    period={selectedPeriod} 
                    onPeriodChange={setSelectedPeriod} 
                  />
                </div>
                <MarketRanking onSelect={handleSymbolSelect} />
              </div>
            )}
          </div>

          {/* Right Sidebar */}
          <div className="space-y-8">
            <section className="bg-slate-900/40 border border-slate-800 p-8 rounded-[2.5rem] shadow-2xl backdrop-blur-md">
              <h3 className="font-black text-white text-xs uppercase tracking-[0.3em] mb-10 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
                  <svg className="w-5 h-5 text-amber-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd"></path></svg>
                </div>
                Safira Analytics
              </h3>
              <div className="space-y-10">
                <div className="relative pl-8 border-l-2 border-blue-500 group cursor-pointer" onClick={() => handleSymbolSelect('NVDA')}>
                  <div className="absolute -left-[5px] top-0 w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.6)]"></div>
                  <p className="text-[11px] font-black text-blue-400 mb-3 uppercase tracking-widest flex items-center gap-2">US Tech <span className="bg-blue-500/10 px-2 py-0.5 rounded text-[8px]">Alert</span></p>
                  <p className="text-xs text-slate-400 leading-relaxed font-bold group-hover:text-slate-200 transition-colors">Yields (10Y) em alta. Atenção ao suporte de <span className="text-blue-300">NVDA</span>.</p>
                </div>
                <div className="relative pl-8 border-l-2 border-emerald-500 group cursor-pointer" onClick={() => handleSymbolSelect('PETR4')}>
                  <div className="absolute -left-[5px] top-0 w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.6)]"></div>
                  <p className="text-[11px] font-black text-emerald-400 mb-3 uppercase tracking-widest flex items-center gap-2">B3 Flow <span className="bg-emerald-500/10 px-2 py-0.5 rounded text-[8px]">Opportunity</span></p>
                  <p className="text-xs text-slate-400 leading-relaxed font-bold group-hover:text-slate-200 transition-colors">Petróleo Brent sobe 1.8%. Impacto direto em <span className="text-emerald-300">PETR4</span> hoje.</p>
                </div>
                <div className="relative pl-8 border-l-2 border-red-500 group">
                  <div className="absolute -left-[5px] top-0 w-2 h-2 rounded-full bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.6)]"></div>
                  <p className="text-[11px] font-black text-red-400 mb-3 uppercase tracking-widest flex items-center gap-2">EU Risk <span className="bg-red-500/10 px-2 py-0.5 rounded text-[8px]">Monitor</span></p>
                  <p className="text-xs text-slate-400 leading-relaxed font-bold group-hover:text-slate-200 transition-colors">BCE sinaliza cautela. Bancos europeus operam em queda moderada.</p>
                </div>
              </div>
            </section>

            <button 
              onClick={() => setActiveTab('chat')}
              className="w-full bg-gradient-to-br from-blue-700 via-indigo-800 to-blue-950 p-12 rounded-[3rem] border border-white/10 relative overflow-hidden shadow-2xl group text-left"
            >
              <div className="absolute -top-16 -right-16 w-56 h-56 bg-white/5 rounded-full blur-[60px] group-hover:bg-white/10 transition-all duration-700"></div>
              <div className="relative z-10">
                <h3 className="font-black text-3xl text-white tracking-tighter italic mb-4 leading-none">Análise <br/>Preditiva</h3>
                <p className="text-blue-100/50 text-[10px] font-black uppercase tracking-[0.2em] mb-10 leading-relaxed">
                  Deep Learning • Global Market Data • High Precision
                </p>
                <div className="flex items-center justify-between mt-auto">
                  <span className="text-xs font-black text-white uppercase tracking-widest border-b-2 border-white/20 pb-1 group-hover:border-white/100 transition-all">Ativar IA</span>
                  <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center group-hover:translate-x-3 transition-transform duration-500 border border-white/5">
                    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                  </div>
                </div>
              </div>
            </button>
          </div>
        </div>
      </main>

      {/* Mobile Nav */}
      <nav className="lg:hidden bg-slate-900/95 border-t border-slate-800/50 backdrop-blur-2xl flex justify-around p-5 sticky bottom-0 z-50">
        <button onClick={() => setActiveTab('chat')} className={`flex flex-col items-center gap-2 ${activeTab === 'chat' ? 'text-blue-400' : 'text-slate-600'}`}>
          <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path></svg>
          <span className="text-[10px] font-black uppercase tracking-widest">Safira</span>
        </button>
        <button onClick={() => setActiveTab('dashboard')} className={`flex flex-col items-center gap-2 ${activeTab === 'dashboard' ? 'text-blue-400' : 'text-slate-600'}`}>
          <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
          <span className="text-[10px] font-black uppercase tracking-widest">Global</span>
        </button>
      </nav>
    </div>
  );
};

export default App;
